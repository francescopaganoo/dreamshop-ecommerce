<?php
/**
 * Deposits tab
 *
 * @package woocommerce-deposits
 */

?>
<li class="wc-deposits-tab advanced_options hide_if_grouped hide_if_external hide_if_composite hide_if_bundle"><a href="#deposits"><span><?php esc_html_e( 'Deposits', 'woocommerce-deposits' ); ?></a></span></li>
