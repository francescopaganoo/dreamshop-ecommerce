<?php
/**
 * Uninstall
 *
 * @package woocommerce-deposits
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}
