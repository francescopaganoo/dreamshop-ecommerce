<?php
// Previene l'accesso diretto
if (!defined('ABSPATH')) {
    exit;
}

// Mostra eventuali errori o messaggi
settings_errors('dreamshop_points');
?>
<div class="wrap dreamshop-points-settings">
    <h1><?php _e('Impostazioni Punti Fedeltà', 'dreamshop-points'); ?></h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('dreamshop_points_settings'); ?>
        <input type="hidden" name="dreamshop_points_save_settings" value="1">
        
        <table class="form-table">
            <tr>
                <th scope="row"><?php _e('Rapporto di guadagno punti', 'dreamshop-points'); ?></th>
                <td>
                    <input type="number" step="0.01" min="0" name="earning_ratio" value="<?php echo esc_attr($earning_ratio); ?>" class="small-text">
                    <p class="description">
                        <?php _e('Numero di punti guadagnati per ogni euro speso. Ad esempio, con un valore di 1, un ordine di 50€ farà guadagnare 50 punti.', 'dreamshop-points'); ?>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><?php _e('Valore di riscatto punti', 'dreamshop-points'); ?></th>
                <td>
                    <input type="number" step="0.01" min="0" name="dreamshop_points_redemption_ratio" value="<?php echo esc_attr($redemption_ratio); ?>" class="small-text">
                    <p class="description">
                        <?php _e('Valore in euro di ogni punto. Ad esempio, con un valore di 0.01, 100 punti valgono 1€ di sconto.', 'dreamshop-points'); ?>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><?php _e('Punti minimi per il riscatto', 'dreamshop-points'); ?></th>
                <td>
                    <input type="number" step="1" min="1" name="dreamshop_points_min_to_redeem" value="<?php echo esc_attr($min_points_to_redeem); ?>" class="small-text">
                    <p class="description">
                        <?php _e('Numero minimo di punti necessari per poter richiedere uno sconto.', 'dreamshop-points'); ?>
                    </p>
                </td>
            </tr>
        </table>
        
        <?php submit_button(__('Salva impostazioni', 'dreamshop-points')); ?>
    </form>
</div>

<style>
.dreamshop-points-settings .form-table th {
    width: 250px;
}
</style>
