<?php
/**
 * Gestisce le API REST per il plugin DreamShop Points
 */
class DreamShop_Points_API {
    
    /**
     * Istanza del database
     *
     * @var DreamShop_Points_DB
     */
    private $db;
    
    /**
     * Costruttore
     */
    public function __construct() {
        $this->db = new DreamShop_Points_DB();
    }
    
    /**
     * Registra gli endpoint dell'API REST
     */
    public function register_endpoints() {
        // Namespace API per DreamShop Points
        $namespace = 'dreamshop/v1';
        
        // Endpoint per ottenere i punti di un utente
        register_rest_route($namespace, '/points/user', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_user_points'),
            'permission_callback' => array($this, 'check_authentication')
        ));
        
        // Endpoint per aggiungere punti a un utente
        register_rest_route($namespace, '/points/add', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_points'),
            'permission_callback' => array($this, 'check_authentication')
        ));
        
        // Endpoint per riscattare punti
        register_rest_route($namespace, '/points/redeem', array(
            'methods' => 'POST',
            'callback' => array($this, 'redeem_points'),
            'permission_callback' => array($this, 'check_authentication')
        ));
    }
    
    /**
     * Verifica che l'utente sia autenticato
     *
     * @param WP_REST_Request $request Richiesta REST
     * @return bool|WP_Error True se autenticato, WP_Error altrimenti
     */
    public function check_authentication($request) {
        // Ottieni l'utente corrente
        $user_id = get_current_user_id();
        
        // Se l'utente non è loggato
        if (!$user_id) {
            return new WP_Error(
                'rest_forbidden',
                'È necessario autenticarsi per accedere a questa risorsa.',
                array('status' => 401)
            );
        }
        
        return true;
    }
    
    /**
     * Ottiene i punti di un utente
     *
     * @param WP_REST_Request $request Richiesta REST
     * @return WP_REST_Response Risposta REST
     */
    public function get_user_points($request) {
        // Ottieni l'utente corrente
        $user_id = get_current_user_id();
        
        // Ottieni i punti dell'utente
        $points = $this->db->get_user_points($user_id);
        
        // Ottieni la cronologia dei punti
        $history = $this->db->get_points_history($user_id);
        
        // Creazione dell'etichetta dei punti
        $points_label = $this->format_points_label($points);
        
        // Restituisci la risposta
        return rest_ensure_response(array(
            'success' => true,
            'user_id' => $user_id,
            'points' => $points,
            'pointsLabel' => $points_label,
            'history' => $history
        ));
    }
    
    /**
     * Aggiunge punti a un utente
     *
     * @param WP_REST_Request $request Richiesta REST
     * @return WP_REST_Response Risposta REST
     */
    public function add_points($request) {
        // Ottieni l'utente corrente
        $user_id = get_current_user_id();
        
        // Ottieni i parametri dalla richiesta
        $params = $request->get_json_params();
        
        // Valida i parametri richiesti
        if (!isset($params['points']) || !is_numeric($params['points']) || $params['points'] <= 0) {
            return new WP_Error(
                'invalid_parameter',
                'Il parametro points è obbligatorio e deve essere un numero positivo.',
                array('status' => 400)
            );
        }
        
        $points = intval($params['points']);
        $description = isset($params['description']) ? sanitize_text_field($params['description']) : 'Punti aggiunti';
        $order_id = isset($params['order_id']) ? intval($params['order_id']) : 0;
        
        // Aggiungi i punti
        $result = $this->db->add_points($user_id, $points, $description, $order_id);
        
        // Se l'operazione ha avuto successo
        if ($result['success']) {
            return rest_ensure_response($result);
        } else {
            return new WP_Error(
                'points_error',
                $result['description'],
                array('status' => 400)
            );
        }
    }
    
    /**
     * Riscatta punti di un utente
     *
     * @param WP_REST_Request $request Richiesta REST
     * @return WP_REST_Response Risposta REST
     */
    public function redeem_points($request) {
        // Ottieni l'utente corrente
        $user_id = get_current_user_id();
        
        // Ottieni i parametri dalla richiesta
        $params = $request->get_json_params();
        
        // Valida i parametri richiesti
        if (!isset($params['points']) || !is_numeric($params['points']) || $params['points'] <= 0) {
            return new WP_Error(
                'invalid_parameter',
                'Il parametro points è obbligatorio e deve essere un numero positivo.',
                array('status' => 400)
            );
        }
        
        $points = intval($params['points']);
        $description = isset($params['description']) ? sanitize_text_field($params['description']) : 'Punti riscattati';
        $order_id = isset($params['order_id']) ? intval($params['order_id']) : 0;
        
        // Riscatta i punti
        $result = $this->db->redeem_points($user_id, $points, $description, $order_id);
        
        // Se l'operazione ha avuto successo
        if ($result['success']) {
            return rest_ensure_response($result);
        } else {
            return new WP_Error(
                'points_error',
                $result['description'],
                array('status' => 400)
            );
        }
    }
    
    /**
     * Formatta l'etichetta dei punti
     *
     * @param int $points Numero di punti
     * @return string Etichetta formattata
     */
    private function format_points_label($points) {
        if ($points === 1) {
            return '1 punto';
        } else {
            return $points . ' punti';
        }
    }
}
